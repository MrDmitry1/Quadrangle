package main.java.com.quadrangle.action;

import main.java.com.quadrangle.entity.Point;

public class PointAction {

	public double defineDistance(Point point) {
		return Math.hypot(point.getX(), point.getY()); // ����������� hypot
	}
}
